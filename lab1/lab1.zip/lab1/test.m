im = imread("hawk.jpg");
imshow(im);